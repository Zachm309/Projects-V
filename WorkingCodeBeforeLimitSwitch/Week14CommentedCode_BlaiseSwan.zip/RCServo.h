#include "stm32f303xe.h"
#ifndef __RCServo_h
#define __RCServo_h

uint16_t RCServo_SetAngle( int16_t angle );
void RCServo_Init(void);

#endif 