#include "stm32f303xe.h"

#define MAX_PWM 1000

void Encoder_Init(void);
void TIM2_IRQHandler(void);
uint32_t encoder_read_left(void);
uint32_t encoder_read_right(void);