
#include "stm32f303xe.h"

void matrix_init(void);
uint8_t MatrixScan(void);