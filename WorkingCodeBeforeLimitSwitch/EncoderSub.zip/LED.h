#include "stm32f303xe.h"

void LED_INIT(void);
void TOGGLE(void);
void mainMenu(void);