#include "stm32f303xe.h"
#include "Encoder.h"

uint32_t left_last_timestamp = 0;
uint32_t right_last_timestamp = 0;

void Encoder_Init(void)
{
	// Enable GPIO Port A	
		// PA0 for Input Capture on Left Wheel
		// PA1 for Input Capture on Right Wheel
	

	
	
	// Configure TIM2 for Both CH1 and CH2 inputs
	
	// Enable TIM2 on APB1
	// Set Prescaler to 1us
	// Set counting direction to upcounting
	
	
	
	
	
	// Configure TIM2 CH1 for input capture on Left Encoder
	
	// Select input capture mode for CH1 (normal mode  0%01)
	//   By setting CC1S to 0%01 in CCMR1
	
	// ENABLE_GPIO_CLOCK input capture for CH1
	//   BY setting CC1E in CCER
	
	// Detect rising edges (by clearing both input capture mode bits)
	//	 Clear both CC1P and CC1NP in CCER
	
	// Clear CCR1 of any garbage values by setting CCR1 = 0
	
	// Enable GPIO Port A clock
RCC->AHBENR |= RCC_AHBENR_GPIOAEN;

// Configure PA0 as alternate function mode (AF2) for TIM2 CH1
GPIOA->MODER &= ~GPIO_MODER_MODER0;
GPIOA->MODER |= GPIO_MODER_MODER0_1;
GPIOA->AFR[0] |= 2 << GPIO_AFRL_AFRL0_Pos;

// Enable TIM2 clock
RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

// Configure TIM2 CH1 for input capture
TIM2->CCMR1 &= ~TIM_CCMR1_CC1S_Msk; // select input capture mode (normal mode)
TIM2->CCMR1 |= TIM_CCMR1_CC1S_0;
TIM2->CCER |= TIM_CCER_CC1E; // enable input capture for CH1
TIM2->CCER &= ~(TIM_CCER_CC1P | TIM_CCER_CC1NP); // detect rising edges
TIM2->CNT = 0; // clear counter
TIM2->CCR1 = 0; // clear CCR1 of any garbage values
TIM2->CR1 |= TIM_CR1_CEN; // start counter
	
	
	
	// Configure TIM2 CH2 for input capture on Right Encoder
	
	// Select input capture mode for CH2 (normal mode  0%01)
		// BY setting CC2S to 0%01
		
	// ENABLE_GPIO_CLOCK input capture for CH2
		// By setting CC2E in CCER
		
	// Detect rising edges (by clearing both input capture mode bits)
		// By clearing both CC2P ad CC2NP in CCER
		
	// Clear CCR2 of any garbage values by setting CCR2 = 0
	
	// Enable GPIO Port A clock
//RCC->AHBENR |= RCC_AHBENR_GPIOAEN; already dcid this!

// Configure PA1 as alternate function mode (AF2) for TIM2 CH2
GPIOA->MODER &= ~GPIO_MODER_MODER1;
GPIOA->MODER |= GPIO_MODER_MODER1_1;
GPIOA->AFR[0] |= 2 << GPIO_AFRL_AFRL1_Pos;

// Enable TIM2 clock
RCC->APB1ENR |= RCC_APB1ENR_TIM2EN;

// Configure TIM2 CH2 for input capture
TIM2->CCMR1 &= ~TIM_CCMR1_CC2S_Msk; // select input capture mode (normal mode)
TIM2->CCMR1 |= TIM_CCMR1_CC2S_0;
TIM2->CCER |= TIM_CCER_CC2E; // enable input capture for CH2
TIM2->CCER &= ~(TIM_CCER_CC2P | TIM_CCER_CC2NP); // detect rising edges
TIM2->CNT = 0; // clear counter
TIM2->CCR2 = 0; // clear CCR2 of any garbage values
TIM2->CR1 |= TIM_CR1_CEN; // start counter
	
	
	
	// Configure TIM2 to generate interrupts and configure NVIC to respond
	
	// Enable Encoder channels to trigger IRQ
		// BY setting CC1IE and CC2IE in DIER
		
	// Enable Timer 2 IRQ (TIM2_IRQn) in NVIC and set its priority to any... 
	
	// Enable Encoder channels to trigger IRQ
TIM2->DIER |= TIM_DIER_CC1IE | TIM_DIER_CC2IE;

// Enable Timer 2 IRQ (TIM2_IRQn) in NVIC and set its priority to any...
NVIC_SetPriority(TIM2_IRQn, 0);
NVIC_EnableIRQ(TIM2_IRQn);
	 
	 
	 
	
	// Start TIM2 CH1 and CH2 Input Captures
	
	// 1. Force an update event to preload all the registers
	//		By setting UG in EGR
	
	// 2. Enable TIM15 to start counting
	//		By setting CEN in CR1
	
	// Force an update event to preload all the registers
TIM2->EGR |= TIM_EGR_UG;

// Enable TIM2 to start counting
TIM2->CR1 |= TIM_CR1_CEN;

}


void TIM2_IRQHandler( void )
{

	// In TIM2 IRQ handler
	
	// Check which channel (CCR1 or CCR2) fired the interrupt by checking
	//    If CCR1 (Left Wheel) triggers the IRQ, CC1IF in SR will be set
	//    IF CCR2 (Right Wheel) triggers the IRQ, CC2IF in SR will be set
	
	// Then, in each respective case, read the CCR value as the CURRENT TIMESTAMP
	// 	1. Encooder Period = CURRENT TIMESTAMP - MOST RECENT HISTORICAL
	//  2. Update MOST RECENT HISTORICAL = CURRENT TIMESTAMP
	
	
	// [Question for you]:  What happens if timer counter overflows?
	//			i.e. takes too long for the vane to pass through the optical assembly?
	
	//  We will answer this at the end of the lab session

	// Check if CH1 (left wheel) triggered the interrupt
    if ((TIM2->SR & TIM_SR_CC1IF) != 0) {
        uint32_t current_timestamp = TIM2->CCR1;
        uint32_t period = current_timestamp - left_last_timestamp;
        left_last_timestamp = current_timestamp;
        // Do something with the period value (e.g. calculate velocity)
    }

    // Check if CH2 (right wheel) triggered the interrupt
    if ((TIM2->SR & TIM_SR_CC2IF) != 0) {
        uint32_t current_timestamp = TIM2->CCR2;
        uint32_t period = current_timestamp - right_last_timestamp;
        right_last_timestamp = current_timestamp;
        // Do something with the period value (e.g. calculate velocity)
    }

    // Clear interrupt flags
    TIM2->SR &= ~(TIM_SR_CC1IF | TIM_SR_CC2IF);
	
}

uint32_t encoder_read_left(void)
{
    // Read the value of the left wheel encoder capture register (CCR1)
    uint32_t left_capture = TIM2->CCR1;

    // Calculate the period between the last two captures
    uint32_t left_period = left_capture - left_last_timestamp;
    
    // Update the last timestamp with the current capture value
    left_last_timestamp = left_capture;

    // Return the period
    return left_period;
}

uint32_t encoder_read_right(void)
{
    // Read the value of the right wheel encoder capture register (CCR2)
    uint32_t right_capture = TIM2->CCR2;

    // Calculate the period between the last two captures
    uint32_t right_period = right_capture - right_last_timestamp;

    // Update the last timestamp with the current capture value
    right_last_timestamp = right_capture;

    // Return the period
    return right_period;
}